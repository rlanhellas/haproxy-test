## Changelog
* 882dbb67 BUILD/MINOR: go.mod: upgrade client-native
* 0c73bcd4 TEST/MINOR: e2e: remove unsupported versions from testing
